import csv
import os

# --- 1. Definición de rutas y archivos ---
# Asumimos que los archivos están en el mismo directorio que el script o especificas la ruta.
# Reemplaza 'nombre_carpeta' si tienes tus archivos dentro de un directorio específico.
FOLDER_PATH = "."  # Ruta actual, ajusta si es necesario
FILE_UF1 = os.path.join(FOLDER_PATH, 'notas_alumnos_UF1.csv')
FILE_UF2 = os.path.join(FOLDER_PATH, 'notas_alumnos_UF2.csv')
FILE_OUTPUT = os.path.join(FOLDER_PATH, 'notas_alumnos.csv')

DELIMITER = ';'  # El delimitador que se observa en los datos de la práctica

# --- 2. Lectura y Combinación de Datos ---

# Un diccionario para guardar los datos combinados, usando el 'Id' como clave
datos_combinados = {}
nombres_columnas_salida = ["Id", "Apellidos", "Nombre", "UF1", "UF2"]

try:
    # 2.1. Leer el archivo UF1
    with open(FILE_UF1, 'r', newline='', encoding='utf-8') as file_uf1:
        # csv.DictReader lee cada fila como un diccionario usando la cabecera
        reader_uf1 = csv.DictReader(file_uf1, delimiter=DELIMITER)

        # Guardar los datos de UF1
        for fila in reader_uf1:
            # Quitamos los espacios extra en las claves por si acaso
            id_alumno = fila['Id'].strip()

            # Inicializamos la entrada en el diccionario con la información básica y la nota de UF1
            datos_combinados[id_alumno] = {
                "Id": id_alumno,
                "Apellidos": fila['Apellidos'].strip(),
                "Nombre": fila['Nombre'].strip(),
                "UF1": fila['UF1'].strip(),
                "UF2": ""  # Inicializamos UF2 vacía
            }

    # 2.2. Leer el archivo UF2
    with open(FILE_UF2, 'r', newline='', encoding='utf-8') as file_uf2:
        reader_uf2 = csv.DictReader(file_uf2, delimiter=DELIMITER)

        # Añadir la nota de UF2 a los datos existentes
        for fila in reader_uf2:
            id_alumno = fila['Id'].strip()

            if id_alumno in datos_combinados:
                # Si el alumno ya está (del archivo UF1), añadimos la nota de UF2
                datos_combinados[id_alumno]["UF2"] = fila['UF2'].strip()
            else:
                # Manejar el caso de que un alumno esté solo en UF2 (opcional)
                print(f"Advertencia: El alumno con Id {id_alumno} está en UF2 pero no en UF1. Se añadirá.")
                datos_combinados[id_alumno] = {
                    "Id": id_alumno,
                    "Apellidos": fila['Apellidos'].strip(),
                    "Nombre": fila['Nombre'].strip(),
                    "UF1": "",
                    "UF2": fila['UF2'].strip()
                }

    # --- 3. Escritura del Archivo de Salida ---

    # 3.1. Abrir el archivo de salida en modo escritura ('w')
    with open(FILE_OUTPUT, 'w', newline='', encoding='utf-8') as file_output:
        # Crear el objeto DictWriter
        writer = csv.DictWriter(
            file_output,
            fieldnames=nombres_columnas_salida,
            delimiter=DELIMITER
        )  # Es importante definir los fieldnames para DictWriter

        # 3.2. Escribir las cabeceras
        writer.writeheader()  # Escribe la fila de cabeceras

        # 3.3. Escribir los datos combinados
        # Los valores se obtienen del diccionario datos_combinados
        for id_alumno in sorted(datos_combinados.keys()):  # Opcional: ordenar por Id
            writer.writerow(datos_combinados[id_alumno])  # writerow toma un diccionario

    print(f"\n✅ Éxito: Los datos se han combinado y guardado en '{FILE_OUTPUT}'")

except FileNotFoundError:
    print(
        f"\n❌ Error: Asegúrate de que los archivos de entrada ({os.path.basename(FILE_UF1)} y {os.path.basename(FILE_UF2)}) existen en la ruta: {FOLDER_PATH}")
except Exception as e:
    print(f"\n❌ Ha ocurrido un error inesperado: {e}")